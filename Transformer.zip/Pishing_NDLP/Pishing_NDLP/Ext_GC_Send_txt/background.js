chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "sendContent") {
      var bodyContent = request.body;
      sendContentToServer(bodyContent);
  }
});

function sendContentToServer(content) {
  fetch('http://127.0.0.1:5000/predict', {
      method: 'POST',
      headers: {
          'Content-Type': 'text/plain'
      },
      body: content
  })
  .then(response => {
      if (response.ok) {
          return response.text();
      } else {
          console.log('Failed to send information to the server.');
      }
  })
  .then(result => {
      var resultNum = parseFloat(result);

      if (!isNaN(resultNum)) {
          var resultMult = resultNum * 100;

          //alert('This page has a ' + resultMult + '% probability of being Phishing.');
          var div = document.createElement("div");
          div.style.width = "100px";
          div.style.height = "100px";
          div.style.background = "red";
          div.style.color = "white";
          div.innerHTML = "Hello";
          
         var vr= document.body.appendChild(div);
         return vr;


         
      } else {
          // Manejar el caso en el que el resultado no es un número
          Swal.fire('Error', 'El resultado del servidor no es un número válido.', 'error');
      }
  })
  .catch(error => {
      console.log('Error en la solicitud:', error);
  });
}
