chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "getTextFromPage") {
      var bodyContent = document.body.innerText;
      chrome.runtime.sendMessage({ action: "sendContent", body: bodyContent });
    }
  });
  