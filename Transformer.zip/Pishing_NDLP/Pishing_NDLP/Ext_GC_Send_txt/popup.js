document.addEventListener("DOMContentLoaded", function () {
    var sendButton = document.getElementById("sendButton");
    //console.log("hola");
    sendButton.addEventListener("click", function () {
        // Ejecuta un script en la pestaña activa actual para obtener el contenido del body
        chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: "getTextFromPage"});
            //console.log("hola2");
        });
    });
});
